import React from 'react'
import {Switch, Route, Redirect} from 'react-router-dom'
//import { Club } from './components/Club'
import { Table } from './components/Club'

import { MainMenu } from './components/MainMenu'
import {types} from './components/Club'

export const Routes = () => {

    const clubTable = [
        {field: 'id', type: types.number},
        {field: 'name', type: types.string},
    ]

    


    return(
        <Switch>
            <Route path="/" exact>
                <MainMenu />
            </Route>
            <Route path="/clubs" exact>
                {/* <Club table={clubTable} tableName="club"/> */}
                <Table table={clubTable} tableName="club"/>
            </Route>
            <Redirect to="/" />
        </Switch>
    )}
