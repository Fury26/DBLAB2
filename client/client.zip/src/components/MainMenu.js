import React, {Fragment} from 'react'
import './styles.css'
import {NavLink} from 'react-router-dom'

export const MainMenu = () => {
    return (
        <Fragment>
            <div className="mainmenu">
                <NavLink className="nav-link" to="/clubs" >
                    <div className="card"><span className="card-title">Clubs</span></div>
                </NavLink>
                <div className="card"><span className="card-title" >Players</span></div>
            </div>
        </Fragment>
    )
}

