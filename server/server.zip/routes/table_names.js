const tables = {
    club : 'club',
    clubs_tournaments : 'clubs_tournaments',
    club_stadium : 'club_stadium',
    player : 'player',
    tournament : 'tournament',
    match : 'match',
    stadium : 'stadium',
}

module.exports = tables